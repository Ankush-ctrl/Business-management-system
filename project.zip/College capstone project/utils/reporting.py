import pandas as pd
from tkinter import messagebox
from tkinter.filedialog import asksaveasfilename

def generate_report(df):
    try:
        file = asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
        if not file:
            return

        with pd.ExcelWriter(file) as writer:
            df.to_excel(writer, index=False, sheet_name="Raw Data")

            summary = {
                "Total Revenue": [df['Sell Price'].sum()],
                "Total Cost": [df['Cost Price'].sum()],
                "Total Profit": [(df['Sell Price'] - df['Cost Price']).sum()]
            }
            pd.DataFrame(summary).to_excel(writer, sheet_name="Summary", index=False)

        messagebox.showinfo("Success", "Report exported successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Report failed: {e}")
