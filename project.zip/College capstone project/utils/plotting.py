import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np

def show_cash_flow_graph(monthly, container):
    for widget in container.winfo_children():
        widget.destroy()

    # Setup
    fig, ax = plt.subplots(figsize=(10, 5))
    index = np.arange(len(monthly))
    bar_width = 0.35

    # Bars
    bars1 = ax.bar(index - bar_width/2, monthly['Cash In'], bar_width,
                   label='Cash In', color='#4CAF50', edgecolor='black')
    bars2 = ax.bar(index + bar_width/2, monthly['Cash Out'], bar_width,
                   label='Cash Out', color='#F44336', edgecolor='black')

    # Labels & Style
    ax.set_xlabel('Month', fontsize=12)
    ax.set_ylabel('Amount (₹)', fontsize=12)
    ax.set_title('Monthly Cash Flow', fontsize=14, fontweight='bold')
    ax.set_xticks(index)
    ax.set_xticklabels(monthly.index, rotation=45)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.6)
    ax.set_facecolor('#f8f8f8')

    # Embed to Tkinter
    canvas = FigureCanvasTkAgg(fig, master=container)
    canvas.draw()
    canvas.get_tk_widget().pack(fill='both', expand=True)
