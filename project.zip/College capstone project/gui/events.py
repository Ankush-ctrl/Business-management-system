import os
import pandas as pd
from tkinter import filedialog, messagebox
from utils.calculations import (
    calculate_metrics,
    calculate_cash_flow,
    calculate_growth,
    calculate_ratios
)
from utils.plotting import show_cash_flow_graph
from utils.reporting import generate_report

widgets = {}

def bind_events(ui_widgets):
    global widgets
    widgets = ui_widgets
    widgets["load_btn"].config(command=load_excel)
    widgets["report_btn"].config(command=generate_report_button)

def load_excel():
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls")])
    if not file_path:
        return
    try:
        df = pd.read_excel(file_path)
        df.columns = df.columns.str.strip()

        required = {'Date', 'Item', 'Cost Price', 'Sell Price', 'Quantity', 'Type'}
        if not required.issubset(df.columns):
            messagebox.showerror("Error", f"Missing required columns: {required}")
            return

        with open("assets/last_file.txt", "w") as f:
            f.write(file_path)

        update_all(df)

    except Exception as e:
        messagebox.showerror("Error", f"Error loading file:\n{e}")

def load_last_file(ui_widgets):
    global widgets
    widgets = ui_widgets

    try:
        if os.path.exists("assets/last_file.txt"):
            with open("assets/last_file.txt", "r") as f:
                path = f.read().strip()
                if os.path.exists(path):
                    df = pd.read_excel(path)
                    df.columns = df.columns.str.strip()
                    update_all(df)
    except:
        pass

def update_all(df):
    metrics = calculate_metrics(df)
    update_balance_sheet(metrics)

    monthly, quarterly, fy = calculate_cash_flow(df)
    update_cash_flow(monthly, quarterly, fy)
    show_cash_flow_graph(monthly, widgets["graphs_tab"])

    update_product_table(df)
    update_growth_tracker(df)
    update_ratios(df)

def update_balance_sheet(metrics):
    tree = widgets["balance_tree"]
    tree.delete(*tree.get_children())
    for key, val in metrics.items():
        tree.insert('', 'end', values=(key, f"{val:,.2f}"))

def update_cash_flow(monthly, quarterly, fy):
    m_tree = widgets["month_tree"]
    q_tree = widgets["quarter_tree"]

    m_tree.delete(*m_tree.get_children())
    q_tree.delete(*q_tree.get_children())

    for index, row in monthly.iterrows():
        m_tree.insert('', 'end', values=(index, f"{row.get('Cash In', 0):,.2f}", f"{row.get('Cash Out', 0):,.2f}"))
    m_tree.insert('', 'end', values=("Total", f"{monthly.get('Cash In', pd.Series()).sum():,.2f}", f"{monthly.get('Cash Out', pd.Series()).sum():,.2f}"))

    for index, row in quarterly.iterrows():
        q_tree.insert('', 'end', values=(str(index), f"{row.get('Cash In', 0):,.2f}", f"{row.get('Cash Out', 0):,.2f}"))
    q_tree.insert('', 'end', values=("Total", f"{quarterly.get('Cash In', pd.Series()).sum():,.2f}", f"{quarterly.get('Cash Out', pd.Series()).sum():,.2f}"))

    widgets["fy_label"].config(text=f"Financial Year Cash Flow:\nCash In: ₹{fy['FY Cash In']:,.2f} | Cash Out: ₹{fy['FY Cash Out']:,.2f}")

def update_product_table(df):
    df['Profit'] = (df['Sell Price'] - df['Cost Price']) * df['Quantity']
    df['Revenue'] = df['Sell Price'] * df['Quantity']
    summary = df.groupby('Item').agg({
        'Quantity': 'sum',
        'Revenue': 'sum',
        'Profit': 'sum'
    }).reset_index()
    summary['Profit Margin (%)'] = (summary['Profit'] / summary['Revenue']) * 100

    tree = widgets["product_tree"]
    tree.delete(*tree.get_children())
    for _, row in summary.iterrows():
        tree.insert('', 'end', values=(row['Item'], int(row['Quantity']),
                                       f"{row['Revenue']:,.2f}",
                                       f"{row['Profit']:,.2f}",
                                       f"{row['Profit Margin (%)']:,.2f}%"))

def update_growth_tracker(df):
    growth_df = calculate_growth(df)
    tree = widgets["growth_tree"]
    tree.delete(*tree.get_children())

    for _, row in growth_df.iterrows():
        tree.insert('', 'end', values=(str(row['Month']), f"{row['Growth %']:,.2f}%"))

def update_ratios(df):
    ratios = calculate_ratios(df)
    tree = widgets["ratios_tree"]
    tree.delete(*tree.get_children())
    for key, val in ratios.items():
        tree.insert('', 'end', values=(key, f"{val:,.2f}"))

def generate_report_button():
    try:
        if os.path.exists("assets/last_file.txt"):
            with open("assets/last_file.txt", "r") as f:
                path = f.read().strip()
                if os.path.exists(path):
                    df = pd.read_excel(path)
                    df.columns = df.columns.str.strip()
                    generate_report(df)
                    messagebox.showinfo("Success", "Report generated successfully!")
                else:
                    messagebox.showwarning("Warning", "Excel file not found.")
    except Exception as e:
        messagebox.showerror("Error", f"Report generation failed:\n{e}")
