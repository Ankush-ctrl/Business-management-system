def calculate_metrics(df):
    df['Profit'] = (df['Sell Price'] - df['Cost Price']) * df['Quantity']
    df['Revenue'] = df['Sell Price'] * df['Quantity']

    total_sales = df[df['Type'] == 'Cash In']['Revenue'].sum()
    total_purchases = df[df['Type'] == 'Cash Out']['Cost Price'].sum()
    total_profit = df['Profit'].sum()

    profit_margin = (total_profit / total_sales * 100) if total_sales else 0
    gross_margin = (total_profit / df['Revenue'].sum() * 100) if df['Revenue'].sum() else 0

    return {
        'Total Sales': total_sales,
        'Total Purchases': total_purchases,
        'Profit': total_profit,
        'Profit Margin (%)': profit_margin,
        'Gross Margin (%)': gross_margin
    }

def calculate_cash_flow(df):
    import pandas as pd
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df.dropna(subset=['Date'], inplace=True)
    df['Month'] = df['Date'].dt.strftime('%B')
    df['Quarter'] = df['Date'].dt.to_period('Q-MAR')

    monthly = df.groupby(['Month', 'Type'])['Sell Price'].sum().unstack(fill_value=0)
    quarterly = df.groupby(['Quarter', 'Type'])['Sell Price'].sum().unstack(fill_value=0)

    fy_start = pd.Timestamp(f"{df['Date'].min().year}-04-01")
    fy_end = pd.Timestamp(fy_start.year + 1, 3, 31)
    fy_df = df[(df['Date'] >= fy_start) & (df['Date'] <= fy_end)]

    fy_in = fy_df[fy_df['Type'] == 'Cash In']['Sell Price'].sum()
    fy_out = fy_df[fy_df['Type'] == 'Cash Out']['Sell Price'].sum()

    return monthly, quarterly, {'FY Cash In': fy_in, 'FY Cash Out': fy_out}
