import tkinter as tk
from tkinter import ttk
from gui.layout import setup_tabs, apply_dark_mode
from gui.events import bind_events, load_last_file

root = tk.Tk()
root.title("📊 Company Finance Dashboard")
root.geometry("1050x750")

apply_dark_mode(root)
widgets = setup_tabs(root)
bind_events(widgets)
load_last_file(widgets)

root.mainloop()
