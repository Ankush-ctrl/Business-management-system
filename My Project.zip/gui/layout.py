import tkinter as tk
from tkinter import ttk

def apply_dark_mode(root):
    style = ttk.Style()
    style.theme_use('clam')
    style.configure(".", background="#2e2e2e", foreground="white", fieldbackground="#3e3e3e")
    style.configure("Treeview", background="#1e1e1e", fieldbackground="#1e1e1e", foreground="white")
    style.map("Treeview", background=[("selected", "#4a6984")])
    root.configure(bg="#2e2e2e")

def setup_tabs(root):
    tab_control = ttk.Notebook(root)

    balance_tab = ttk.Frame(tab_control)
    cash_tab = ttk.Frame(tab_control)
    graphs_tab = ttk.Frame(tab_control)
    product_tab = ttk.Frame(tab_control)

    tab_control.add(balance_tab, text='Balance Sheet')
    tab_control.add(cash_tab, text='Cash Flow')
    tab_control.add(graphs_tab, text='Graphs')
    tab_control.add(product_tab, text='Product Profit')
    tab_control.pack(expand=True, fill='both')

    widgets = {}

    # Balance Sheet tab
    load_btn = ttk.Button(balance_tab, text="📂 Load Excel File")
    load_btn.pack(pady=10)
    balance_tree = ttk.Treeview(balance_tab, columns=("Metric", "Value"), show="headings")
    balance_tree.heading("Metric", text="Metric")
    balance_tree.heading("Value", text="Value")
    balance_tree.pack(expand=True, fill='both', padx=20, pady=10)

    # Cash Flow tab
    ttk.Label(cash_tab, text="Monthly Cash Flow").pack(pady=5)
    month_tree = ttk.Treeview(cash_tab, columns=("Month", "Cash In", "Cash Out"), show="headings")
    for col in ("Month", "Cash In", "Cash Out"):
        month_tree.heading(col, text=col)
    month_tree.pack(expand=True, fill='both', padx=20, pady=10)

    ttk.Label(cash_tab, text="Quarterly Cash Flow").pack(pady=5)
    quarter_tree = ttk.Treeview(cash_tab, columns=("Quarter", "Cash In", "Cash Out"), show="headings")
    for col in ("Quarter", "Cash In", "Cash Out"):
        quarter_tree.heading(col, text=col)
    quarter_tree.pack(expand=True, fill='both', padx=20, pady=10)

    fy_label = ttk.Label(cash_tab, text="Financial Year Cash Flow:")
    fy_label.pack(pady=10)

    # Product tab
    product_tree = ttk.Treeview(product_tab, columns=("Item", "Qty", "Revenue", "Profit", "Profit Margin (%)"), show="headings")
    for col in ("Item", "Qty", "Revenue", "Profit", "Profit Margin (%)"):
        product_tree.heading(col, text=col)
    product_tree.pack(expand=True, fill='both', padx=20, pady=10)

    widgets.update({
        "load_btn": load_btn,
        "balance_tree": balance_tree,
        "month_tree": month_tree,
        "quarter_tree": quarter_tree,
        "fy_label": fy_label,
        "product_tree": product_tree,
        "graphs_tab": graphs_tab,
    })

    return widgets
